import express from "express";
import cors from "cors";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import { env } from "./config/env";
import { errorHandler } from "./middleware/errorHandler";

import authRoutes from "./routes/auth";
import templatesRoutes from "./routes/templates";
import documentsRoutes from "./routes/documents";
import subscriptionsRoutes from "./routes/subscriptions";

const app = express();

app.use(helmet());
app.use(
  cors({
    origin: env.CORS_ORIGIN.split(",").map((s) => s.trim()),
    credentials: true,
  })
);
app.use(express.json({ limit: "2mb" }));
app.use(cookieParser());

app.get("/health", (_req, res) => {
  res.json({ status: "ok", service: "doclix-api", ts: new Date().toISOString() });
});

app.use("/api/auth", authRoutes);
app.use("/api/templates", templatesRoutes);
app.use("/api/documents", documentsRoutes);
app.use("/api/subscriptions", subscriptionsRoutes);

app.use(errorHandler);

export default app;
