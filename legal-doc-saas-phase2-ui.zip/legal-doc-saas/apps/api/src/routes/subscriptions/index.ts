import { Router } from "express";
import { requireAuth } from "../../middleware/auth";
import { asyncHandler } from "../../utils/asyncHandler";
import { prisma } from "../../config/prisma";

const router = Router();
router.use(requireAuth);

router.get(
  "/current",
  asyncHandler(async (req, res) => {
    const sub = await prisma.subscription.findFirst({
      where: {
        tenantId: req.user!.tenantId,
        status: { in: ["TRIALING", "ACTIVE", "PAST_DUE"] },
      },
      include: { plan: true },
      orderBy: { createdAt: "desc" },
    });
    res.json({ subscription: sub });
  })
);

export default router;
