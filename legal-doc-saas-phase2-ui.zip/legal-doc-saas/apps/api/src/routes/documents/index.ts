import { Router } from "express";
import { z } from "zod";
import { asyncHandler } from "../../utils/asyncHandler";
import { validateBody } from "../../utils/validate";
import { requireAuth } from "../../middleware/auth";
import * as documentsService from "../../services/documents/documents.service";

const router = Router();
router.use(requireAuth);

const createSchema = z.object({
  templateId: z.string().min(1),
  title: z.string().max(200).optional(),
  formData: z.record(z.unknown()).optional(),
  state: z.string().optional(),
  language: z.string().optional(),
});

const updateSchema = z.object({
  title: z.string().max(200).optional(),
  formData: z.record(z.unknown()).optional(),
  status: z.enum(["DRAFT", "GENERATED", "FINALIZED", "ARCHIVED"]).optional(),
});

router.get(
  "/",
  asyncHandler(async (req, res) => {
    const docs = await documentsService.listDocuments(
      req.user!.tenantId,
      req.user!.id,
      { status: req.query.status as string | undefined }
    );
    res.json({ documents: docs });
  })
);

router.get(
  "/:id",
  asyncHandler(async (req, res) => {
    const doc = await documentsService.getDocument(
      req.params.id,
      req.user!.tenantId,
      req.user!.id
    );
    res.json({ document: doc });
  })
);

router.post(
  "/",
  validateBody(createSchema),
  asyncHandler(async (req, res) => {
    const doc = await documentsService.createDocument({
      tenantId: req.user!.tenantId,
      userId: req.user!.id,
      ...req.body,
    });
    res.status(201).json({ document: doc });
  })
);

router.patch(
  "/:id",
  validateBody(updateSchema),
  asyncHandler(async (req, res) => {
    const doc = await documentsService.updateDocument(
      req.params.id,
      req.user!.tenantId,
      req.user!.id,
      req.body
    );
    res.json({ document: doc });
  })
);

router.delete(
  "/:id",
  asyncHandler(async (req, res) => {
    await documentsService.softDeleteDocument(
      req.params.id,
      req.user!.tenantId,
      req.user!.id
    );
    res.json({ ok: true });
  })
);

export default router;
