"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { documentsApi } from "@/lib/api";

export default function DocumentEditPage() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;

  const [doc, setDoc] = useState<any>(null);
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [title, setTitle] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [showPreview, setShowPreview] = useState(true);
  const [showForm, setShowForm] = useState(true);

  useEffect(() => {
    documentsApi
      .get(id)
      .then((r) => {
        setDoc(r.document);
        setFormData(r.document.formData || {});
        setTitle(r.document.title || "");
      })
      .catch(() => router.replace("/dashboard/documents"))
      .finally(() => setLoading(false));
  }, [id, router]);

  const schema = doc?.templateVersion?.formSchema?.jsonSchema;
  const properties = schema?.properties || {};
  const required: string[] = schema?.required || [];
  const bodyContent: string = doc?.templateVersion?.bodyContent || "";

  const setField = useCallback((key: string, value: any) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  }, []);

  // Simple placeholder fill for live preview
  function filledPreview(): string {
    let html = bodyContent;
    Object.entries(formData).forEach(([k, v]) => {
      const re = new RegExp(`\\{\\{${k}\\}\\}`, "g");
      html = html.replace(re, v ? String(v) : `<span style="background:#fef3c7;padding:0 2px">[${k}]</span>`);
    });
    // leftover placeholders
    html = html.replace(/\{\{(\w+)\}\}/g, '<span style="background:#fef3c7;padding:0 2px">[$1]</span>');
    return html;
  }

  async function save() {
    setSaving(true);
    setMessage("");
    try {
      const { document } = await documentsApi.update(id, { title, formData });
      setDoc(document);
      setMessage("Saved");
      setTimeout(() => setMessage(""), 2000);
    } catch (err: any) {
      setMessage(err.message || "Save failed");
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-2 border-slate-300 border-t-slate-800 rounded-full animate-spin" />
      </div>
    );
  }
  if (!doc) return null;

  return (
    <div className="space-y-4 pb-28">
      {/* Top meta */}
      <div className="flex items-center gap-2">
        <Link href="/dashboard/documents" className="text-sm text-slate-500 active:text-slate-800">
          ← Back
        </Link>
        {message && (
          <span className="ml-auto text-xs font-medium text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full">
            {message}
          </span>
        )}
      </div>

      <input
        className="input !text-base !font-semibold"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Document title"
      />

      {/* Status: Template info */}
      <div className="status-block">
        <div className="status-header">
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          <span>Template</span>
          <span className="text-slate-400 font-normal ml-auto text-xs">
            {doc.template?.name} · v{doc.templateVersion?.version}
          </span>
        </div>
      </div>

      {/* Collapsible: Form fields */}
      <div className="status-block">
        <button
          type="button"
          className="status-header w-full text-left"
          onClick={() => setShowForm((s) => !s)}
        >
          <svg
            className={`w-4 h-4 text-slate-400 transition ${showForm ? "rotate-90" : ""}`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={2}
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
          </svg>
          <span>Form fields</span>
          <span className="text-xs text-slate-400 font-normal ml-auto">
            {Object.keys(properties).length} fields
          </span>
        </button>
        {showForm && (
          <div className="status-body space-y-3 pt-3">
            {Object.keys(properties).length === 0 ? (
              <p className="text-slate-400">No form schema on this template.</p>
            ) : (
              Object.entries(properties).map(([key, prop]: [string, any]) => {
                const isReq = required.includes(key);
                const type = prop.type || "string";
                const isTextarea =
                  key.includes("address") ||
                  key.includes("description") ||
                  key.includes("statement") ||
                  key.includes("terms") ||
                  key.includes("power");

                return (
                  <div key={key}>
                    <label className="label">
                      {prop.title || key}
                      {isReq && <span className="text-red-500"> *</span>}
                    </label>
                    {type === "integer" || type === "number" ? (
                      <input
                        className="input"
                        type="number"
                        value={formData[key] ?? ""}
                        onChange={(e) =>
                          setField(key, e.target.value === "" ? "" : Number(e.target.value))
                        }
                      />
                    ) : prop.format === "date" ? (
                      <input
                        className="input"
                        type="date"
                        value={formData[key] ?? ""}
                        onChange={(e) => setField(key, e.target.value)}
                      />
                    ) : isTextarea ? (
                      <textarea
                        className="textarea"
                        rows={3}
                        value={formData[key] ?? ""}
                        onChange={(e) => setField(key, e.target.value)}
                      />
                    ) : (
                      <input
                        className="input"
                        type="text"
                        value={formData[key] ?? ""}
                        onChange={(e) => setField(key, e.target.value)}
                      />
                    )}
                  </div>
                );
              })
            )}
          </div>
        )}
      </div>

      {/* Live document preview card */}
      <div className="status-block">
        <button
          type="button"
          className="status-header w-full text-left"
          onClick={() => setShowPreview((s) => !s)}
        >
          <svg
            className={`w-4 h-4 text-slate-400 transition ${showPreview ? "rotate-90" : ""}`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={2}
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
          </svg>
          <span>Preview</span>
          <span className="text-xs text-slate-400 font-normal ml-auto">A4 live</span>
        </button>
        {showPreview && (
          <div className="border-t border-slate-100 bg-slate-50/50 p-3">
            <div className="preview-card">
              <div
                className="preview-page"
                dangerouslySetInnerHTML={{ __html: filledPreview() }}
              />
            </div>
            <p className="text-[10px] text-slate-400 text-center mt-2">
              Yellow highlights = empty fields · PDF export in Phase 3
            </p>
          </div>
        )}
      </div>

      {/* Sticky actions */}
      <div className="fixed bottom-16 left-0 right-0 z-30 px-4 pointer-events-none"
        style={{ paddingBottom: "var(--safe-bottom)" }}
      >
        <div className="max-w-lg mx-auto pointer-events-auto space-y-2">
          <button className="btn-primary shadow-lg" onClick={save} disabled={saving}>
            {saving ? "Saving…" : "Save document"}
          </button>
        </div>
      </div>
    </div>
  );
}
