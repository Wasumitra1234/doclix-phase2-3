"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { authApi, setToken } from "@/lib/api";

export default function SettingsPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    authApi.me().then(setUser).catch(console.error);
  }, []);

  function logout() {
    setToken(null);
    router.replace("/login");
  }

  return (
    <div className="space-y-6">
      <h2 className="text-lg font-bold">Account</h2>

      {user && (
        <div className="card space-y-2">
          <p className="font-medium">
            {user.firstName} {user.lastName}
          </p>
          <p className="text-sm text-slate-500">{user.email}</p>
          <p className="text-sm text-slate-500">{user.tenant?.name}</p>
          <p className="text-xs text-slate-400">Role: {user.role}</p>
        </div>
      )}

      {user?.subscription && (
        <div className="card">
          <h3 className="font-semibold text-sm mb-2">Subscription</h3>
          <p className="text-sm">
            Plan: <strong>{user.subscription.plan?.name || user.subscription.plan?.code}</strong>
          </p>
          <p className="text-sm text-slate-500">Status: {user.subscription.status}</p>
          {user.subscription.periodEnd && (
            <p className="text-xs text-slate-400 mt-1">
              Period ends: {new Date(user.subscription.periodEnd).toLocaleDateString("en-IN")}
            </p>
          )}
          <p className="text-xs text-slate-400 mt-2">Razorpay billing — Phase 3</p>
        </div>
      )}

      <button className="btn-secondary text-red-600 border-red-100" onClick={logout}>
        Logout
      </button>
    </div>
  );
}
