const API_BASE = process.env.NEXT_PUBLIC_API_URL || "";

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("doclix_token");
}

export function setToken(token: string | null) {
  if (typeof window === "undefined") return;
  if (token) localStorage.setItem("doclix_token", token);
  else localStorage.removeItem("doclix_token");
}

export async function api<T = any>(
  path: string,
  opts: RequestInit & { json?: unknown } = {}
): Promise<T> {
  const headers: Record<string, string> = {
    ...(opts.headers as Record<string, string>),
  };
  if (opts.json !== undefined) {
    headers["Content-Type"] = "application/json";
  }
  const token = getToken();
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, {
    ...opts,
    headers,
    body: opts.json !== undefined ? JSON.stringify(opts.json) : opts.body,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || res.statusText || "Request failed") as any;
    err.status = res.status;
    err.details = data.details;
    throw err;
  }
  return data as T;
}

export const authApi = {
  register: (body: {
    tenantName: string;
    email: string;
    password: string;
    firstName: string;
    lastName?: string;
    phone?: string;
  }) => api<{ token: string; user: any }>("/api/auth/register", { method: "POST", json: body }),
  login: (body: { email: string; password: string }) =>
    api<{ token: string; user: any }>("/api/auth/login", { method: "POST", json: body }),
  me: () => api<any>("/api/auth/me"),
};

export const templatesApi = {
  list: (params?: Record<string, string>) => {
    const q = params ? "?" + new URLSearchParams(params).toString() : "";
    return api<{ templates: any[] }>(`/api/templates${q}`);
  },
  get: (id: string) => api<{ template: any }>(`/api/templates/${id}`),
};

export const documentsApi = {
  list: () => api<{ documents: any[] }>("/api/documents"),
  get: (id: string) => api<{ document: any }>(`/api/documents/${id}`),
  create: (body: { templateId: string; title?: string; formData?: Record<string, unknown> }) =>
    api<{ document: any }>("/api/documents", { method: "POST", json: body }),
  update: (id: string, body: { title?: string; formData?: Record<string, unknown> }) =>
    api<{ document: any }>(`/api/documents/${id}`, { method: "PATCH", json: body }),
  remove: (id: string) => api(`/api/documents/${id}`, { method: "DELETE" }),
};
