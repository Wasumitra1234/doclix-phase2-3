# Doclix – Phase 2

Cloud-hosted, mobile-first Legal Document Automation SaaS.

## Phase 2 Complete

- ✅ Auth (Register / Login / JWT / Me)
- ✅ Tenant isolation on all document & template APIs
- ✅ Templates list + detail (system + tenant)
- ✅ Documents CRUD (create from template, edit form fields, soft delete)
- ✅ Usage-aware create (plan limits ready)
- ✅ Mobile-first UI (360–430px, bottom nav, touch targets 48px)
- ✅ Dynamic form renderer from FormSchema JSON
- ✅ Cloud-ready env vars (no laptop required for production)

## Local dev (optional – developers only)

```bash
cp .env.example .env
# set DATABASE_URL

npm install
npx prisma generate --schema=prisma/schema.prisma
npx prisma migrate dev --name phase2 --schema=prisma/schema.prisma
npx prisma db seed

# terminal 1
npm run dev:api

# terminal 2
npm run dev:web
```

Web: http://localhost:3000  
API: http://localhost:4000/health

## Production deploy (phone-only operation)

1. **Database**: Neon / Supabase / Railway PostgreSQL → copy `DATABASE_URL`
2. **API**: Deploy `apps/api` to Railway or Render  
   - Set env: `DATABASE_URL`, `JWT_SECRET`, `CORS_ORIGIN`, `PORT`
3. **Web**: Deploy `apps/web` to Vercel  
   - Set env: `NEXT_PUBLIC_API_URL` = your API URL
4. Run migrate + seed once against production DB
5. Open the Vercel HTTPS URL on Android Chrome

No `npm run dev` needed on your phone. The deployed URL is enough.

## Phase 3 (next)

- Camera/gallery upload + cloud storage (R2)
- Server-side OCR
- Server-side A4 PDF generation + preview/download/share
- Razorpay subscriptions
- Public HTTPS verification on 360/390/430px
